import os
import openai
from dotenv import load_dotenv

load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

def generate_reply(prompt, price_info=None):
    system_msg = "Ты — СМЕТА БАТИ. Считатель смет, бригадир по жизни. Отвечай по делу, по-пацански, с харизмой."
    full_prompt = f"{prompt}\n\n{price_info if price_info else ''}"
    
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": system_msg},
            {"role": "user", "content": full_prompt}
        ],
        temperature=0.7
    )
    return response['choices'][0]['message']['content']
