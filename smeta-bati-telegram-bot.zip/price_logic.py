import pandas as pd

def load_prices(file_path='price.xlsx'):
    try:
        df = pd.read_excel(file_path)
        return df
    except Exception:
        return pd.DataFrame(columns=["Вид работы", "Ед. изм.", "Цена от, ₽"])

def get_price_by_query(query, df):
    for index, row in df.iterrows():
        if row['Вид работы'].lower() in query.lower():
            return f"{row['Вид работы']}: {row['Цена от, ₽']}₽ за {row['Ед. изм.']}"
    return "Не нашёл точную цену, но могу рассчитать примерно."
