import logging
import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, MessageHandler, filters
from dotenv import load_dotenv
from gpt_logic import generate_reply
from price_logic import load_prices, get_price_by_query

load_dotenv()
BOT_TOKEN = os.getenv("TELEGRAM_TOKEN")
prices = load_prices()

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Брат, это СМЕТА БАТИ. Пиши, что считать — разрулим.")

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_text = update.message.text
    price_info = get_price_by_query(user_text, prices)
    gpt_reply = generate_reply(user_text, price_info)
    await update.message.reply_text(gpt_reply)

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
app.run_polling()
